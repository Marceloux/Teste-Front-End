let currentQuestion = 1;
let answers = {};

function selectAnswer(questionId, answerElement) {
    const correctAnswers = {
        'question1': 'Brasília',
        'question2': 'Júpiter',
        'question3': 'Sete'
    };

    document.querySelectorAll(`#question${currentQuestion} .answers li`).forEach(li => {
        li.classList.remove('selected');
    });

    answerElement.classList.add('selected');

    document.getElementById(`error${currentQuestion}`).textContent = '';

    answers[questionId] = answerElement.textContent;

    const isCorrect = answerElement.textContent === correctAnswers[questionId];
    if (isCorrect) {
        document.getElementById('nextBtn').disabled = false;
    } else {
        document.getElementById('nextBtn').disabled = true;
        document.getElementById(`error${currentQuestion}`).textContent = 'Resposta errada. Tente novamente.';
    }

    updateFinishButton();
}

function navigate(direction) {
    if (direction === 1) {
        if (!document.querySelector(`#question${currentQuestion} .answers li.selected`)) {
            document.getElementById(`error${currentQuestion}`).textContent = 'Selecione uma alternativa.';
            return;
        }
        
        if (document.getElementById('nextBtn').disabled) {
            document.getElementById(`error${currentQuestion}`).textContent = 'Resposta errada. Tente novamente.';
            return;
        }
    }

    document.getElementById(`question${currentQuestion}`).style.display = 'none';

    currentQuestion += direction;

    if (currentQuestion < 1) currentQuestion = 1;
    if (currentQuestion > 3) currentQuestion = 3;

    document.getElementById(`question${currentQuestion}`).style.display = 'block';

    document.getElementById('prevBtn').style.display = currentQuestion === 1 ? 'none' : 'inline';
    document.getElementById('nextBtn').style.display = currentQuestion === 3 ? 'none' : 'inline';
    document.getElementById('finishBtn').style.display = currentQuestion === 3 ? 'inline' : 'none';

    document.getElementById('nextBtn').disabled = true;
    updateFinishButton();
}

function updateFinishButton() {
    const correctAnswers = {
        'question1': 'Brasília',
        'question2': 'Júpiter',
        'question3': 'Sete'
    };

    const allCorrect = Object.keys(correctAnswers).every(questionId => answers[questionId] === correctAnswers[questionId]);

    document.getElementById('finishBtn').disabled = !allCorrect;
}

function finishQuiz() {
    if (document.getElementById('finishBtn').disabled) {
        alert('Você precisa responder todas as perguntas corretamente antes de finalizar.');
        return;
    }

    document.querySelector('.quiz-container').style.display = 'none';
    document.body.innerHTML += '<div class="thank-you-message">Obrigado por jogar!</div>';
}
